package com.example.holamundo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    //definir 2 widgets
    private EditText editText2;
    private EditText editText2Ape1;
    private EditText editText2Ape2;
    private Button button3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {//se deben recuperar los datos
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);  //Se llama al padre y le envia el bunde - Después se despliega la pantalla main2 ; inflan la pantalla con lo que hace main2

        Bundle bundle = this.getIntent().getExtras();

        //se define en donde se van a mostrar las cosas
        button3 = findViewById(R.id.button3);
        editText2 = findViewById(R.id.editText2);
        editText2Ape1 = findViewById(R.id.editText2Ape1);
        editText2Ape2 = findViewById(R.id.editText2Ape2);

        //ponemos el nombre que atrapo en activity 1 al edittext2
        String nombre = bundle.getString("nombre");
        String ape1 = bundle.getString("primApe");
        String ape2 = bundle.getString("segApe");


        editText2.setText(nombre);
        editText2Ape1.setText(ape1);
        editText2Ape2.setText(ape2);


        //escuchador - llama la intencion, donde la acrtividad2, llama a main actrivi 1
        button3.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(
                        MainActivity2.this, MainActivity.class);
                        startActivity(intent);
                    }
                }
        );

    }
}