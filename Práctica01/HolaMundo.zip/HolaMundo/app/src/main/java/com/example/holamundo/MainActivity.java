package com.example.holamundo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    //para nombre
    private EditText editText1;  //conveniente nombrarlo con el id al que corresponde el widget en el XML
    //para apellidos
    private EditText ape1;
    private EditText ape2;
    private Button button1;
    private Button button2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); //Llama a su padre y manda el bundle
        setContentView(R.layout.activity_main); //toma el XML y lo dibuja.



        editText1= findViewById(R.id.editText1); //La variable JAVA se liga con el widget por su ID en XML
        ape1 = findViewById(R.id.editTextApe1);
        ape2 = findViewById(R.id.editTextApe2);

        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);

        //Boton1
        button1.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String nombre = editText1.getText().toString();  //Todo lo que se recupera de XML es texto
                        String primApe = ape1.getText().toString();
                        String segApe = ape2.getText().toString();

                        Bundle bundle = new Bundle();
                        bundle.putString("nombre", nombre);  //Meterle la cadena de texto
                        bundle.putString("primApe", primApe);
                        bundle.putString("segApe", segApe);
                        //Construyo una intenión. Lo que reciba en this, lo mando a esta class
                        Intent intent = new Intent(
                                MainActivity.this,
                                MainActivity2.class);
                        intent.putExtras(bundle); //mandamos la envoltura, el dato que atrapó en el otro lado - XML
                        startActivity(intent);//Una vez obtenidos los datos, se destruye el mainActivity y se pasa al mainActivity2


                    }
                }
        );

        //Boton2 simplemente sale del sistema al darle click
        button2.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        finishAffinity();
                    }
                }
        );

    }
}