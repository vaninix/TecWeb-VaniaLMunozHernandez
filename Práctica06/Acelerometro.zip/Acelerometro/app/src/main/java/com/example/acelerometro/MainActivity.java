package com.example.acelerometro;

import android.content.pm.ActivityInfo;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    //implement -> simulación de herencia multiple
    private TextView aceX, aceY, aceZ;

    private float actualX=0, actualY=0, actualZ=0;

    private TextView Xmin, Xmax, Ymin, Ymax, Zmin, Zmax;

    // Al inificializar los mímimos o máximos con Float.MIN_VALUE o Float.MAX_VALUE, entonces se asegura que
    //cualquier valor será menor o mayor al inicio:)
    private float minX = Float.MAX_VALUE, maxX = Float.MIN_VALUE;
    private float minY = Float.MAX_VALUE, maxY = Float.MIN_VALUE;
    private float minZ = Float.MAX_VALUE, maxZ = Float.MIN_VALUE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //establece orientacion requerida - Actividad--la orientacion de la pantalla
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        //ligado de variables locales a el id de elementos en XML
        aceX = findViewById(R.id.aceX);
        aceY = findViewById(R.id.aceY);
        aceZ = findViewById(R.id.aceZ);


        Xmin = findViewById(R.id.Xmin);
        Xmax = findViewById(R.id.Xmax);
        Ymin = findViewById(R.id.Ymin);
        Ymax = findViewById(R.id.Ymax);
        Zmin = findViewById(R.id.Zmin);
        Zmax = findViewById(R.id.Zmax);
    }

    @Override
    public void onResume(){
        super.onResume();
        SensorManager sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        //creo lista de acelerometros que tenga
        List<Sensor> sensores =
                sensorManager.getSensorList(Sensor.TYPE_ACCELEROMETER);

        if (sensores.size()>0){
            //registrar el primer acelerometro
            sensorManager.registerListener(this, sensores.get(0), SensorManager.SENSOR_DELAY_GAME);
        }
    }

    //Es necesario sobreescribir el onStop(), para liberar el aceletrometro
    // y que quede disponible para el resto de apps
    @Override
    protected void onStop(){

        SensorManager sensorManager =
                (SensorManager) getSystemService(SENSOR_SERVICE);

        sensorManager.unregisterListener(this);
        super.onStop(); //permite hacer cosa y que lo ultimo que haga sea llamar a su padre
    }

    @Override
    public void onAccuracyChanged (Sensor sensor, int accuracy){   }

    @Override
    public void onSensorChanged(SensorEvent event){
        synchronized (this){
            //esta actividad sincronizala con las que están dentro del proceso
            actualX = event.values[0];
            actualY = event.values[1];
            actualZ = event.values[2];

            aceX.setText("Valor en X: " +actualX);
            aceY.setText("Valor en X: " +actualY);
            aceZ.setText("Valor en X: " +actualZ);


            //Comparar:
            // mínimos y máximos de X
            if (actualX < minX) {
                minX = actualX;
                Xmin.setText(String.valueOf(minX));
            }else if(actualX > maxX) {
                maxX = actualX;
                Xmax.setText(String.valueOf(maxX));
            }

            // mínimos y máximos de Y
            if (actualY < minY) {
                minY = actualY;
                Ymin.setText(String.valueOf(minY));
            }else if (actualY > maxY) {
                maxY = actualY;
                Ymax.setText(String.valueOf(maxY));
            }

            // mínimos y máximos de Z
            if (actualZ < minZ) {
                minZ = actualZ;
                Zmin.setText(String.valueOf(minZ));
            } else if (actualZ > maxZ) {
                maxZ = actualZ;
                Zmax.setText(String.valueOf(maxZ));
            }

        }
    }

}