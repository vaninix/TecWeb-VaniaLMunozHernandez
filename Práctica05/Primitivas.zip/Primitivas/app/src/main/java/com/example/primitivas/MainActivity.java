package com.example.primitivas;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Button btn1, btn2, btn3;
    private Vista vista; // Vista personalizada donde se dibujará

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Carga el diseño del XML

        //Se estableció un id para el Layout en el XML, por lo que puede crearse una instancia de LinearLayout
        // y enlazarlo con la vista/XML, de esta forma es posible agregar al layout principal
        // la vista que estamos creando, donde se dibuja
        LinearLayout layout = findViewById(R.id.layoutPrincipal);
        vista = new Vista(this);
        layout.addView(vista);

        // Se enlazan los botones con el XML
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);

        // Asigna un color a cada botón
        btn1.setOnClickListener(v -> vista.cambiarColor(Color.BLUE));  // Botón 1: Azul
        btn2.setOnClickListener(v -> vista.cambiarColor(Color.RED));   // Botón 2: Rojo
        btn3.setOnClickListener(v -> vista.cambiarColor(Color.GREEN)); // Botón 3: Verde
    }

    // Clase interna para la vista personalizada
    class Vista extends View {
        float x, y; // Coordenadas del toque
        String accion = "accion"; // Acción actual (down o move)
        Path pathActual = new Path(); // Trazo actual que se está dibujando
        Paint paintActual = new Paint(); // Pincel actual con el que se dibuja

        // Clase para guardar un trazo y su color
        class Dibujo {
            Path path; // El camino del trazo
            Paint paint; // Pincel

            Dibujo(Path path, Paint paint) {
                this.path = path;
                this.paint = new Paint(paint); // Crea una copia del pincel
            }
        }

        // Lista para guardar todos los trazos dibujados
        ArrayList<Dibujo> dibujos = new ArrayList<>();
        // Constructor de la vista
        public Vista(Context context) {
            super(context);
            // Configura el pincel inicial
            paintActual.setStyle(Paint.Style.STROKE);
            paintActual.setStrokeWidth(4);
            paintActual.setColor(Color.BLUE);
        }

        // Metodo para cambiar el color del pincel
        public void cambiarColor(int nuevoColor) {
            // Guarda el trazo actual en la lista de dibujos
            dibujos.add(new Dibujo(pathActual, paintActual));

            // Crea un nuevo trazo y un nuevo pincel con el color seleccionado
            pathActual = new Path();
            paintActual = new Paint(paintActual);
            paintActual.setColor(nuevoColor);
            // Redibuja la vista para mostrar los cambios
            invalidate();
        }

        // Metodo que dibuja en la pantalla
        @Override
        protected void onDraw(Canvas canvas) {
            // Dibuja todos los trazos guardados
            for (Dibujo dibujo : dibujos) {
                canvas.drawPath(dibujo.path, dibujo.paint);
            }
            // Dibuja el trazo actual
            canvas.drawPath(pathActual, paintActual);
        }

        // Metodo que detecta los toques en la pantalla
        @Override
        public boolean onTouchEvent(MotionEvent motionEvent) {
            x = motionEvent.getX(); // Obtiene la coordenada X del toque
            y = motionEvent.getY(); // Obtiene la coordenada Y del toque

            if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                // Cuando el usuario toca la pantalla, inicia un nuevo trazo
                accion = "down";
                pathActual.moveTo(x, y); // Mueve el trazo al punto inicial
            }
            if (motionEvent.getAction() == MotionEvent.ACTION_MOVE) {
                // Cuando el usuario mueve el dedo, continúa el trazo
                accion = "move";
                pathActual.lineTo(x, y); // Añade una línea al trazo
            }

            // Redibuja la vista para mostrar el trazo actual
            invalidate();
            return true;
        }
    }
}