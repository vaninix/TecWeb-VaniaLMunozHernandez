package com.example.listadeelementos;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    //se definen objetos de tipo textview y listview
    //que van a almacenar las referencias a los objeto del diseño XML
    private TextView encabezado;
    private ListView listaZodiaco;
    private  TextView info;
    private Button salir;

    private String signos[] = {"Aries", "Tauro",
            "Géminis", "Cáncer",
            "Leo", "Virgo",
            "Libra", "Escorpio",
            "Sagitario", "Capricornio",
            "Acuario", "Piscis"};

    private String periodos[] = {"21-Mar, 19-Abr", "20-Abr, 20-May",
            "21-May, 20-Jun", "21-Jun, 22-Jul",
            "23-Jul, 22-Ago", "23-Ago, 22-Sep",
            "23-Sep, 22-Oct", "23-Oct, 21-Nov",
            "22-Nov, 21-Dic", "22-Dic, 19-Ene",
            "20-Ene, 18-Feb", "19-Feb, 20-Mar"};

    private String informacion[] = {
            "Aries ♈: " + "Eres una persona valiente, decidida y llena de energía. Siempre buscas desafíos y no temes tomar la iniciativa.\n" +
                    "Este año, nuevas oportunidades se abrirán en tu camino.\n" +
                    "🌟 Tendrás que tomar decisiones clave, pero confía en tu instinto.\n" +
                    "El trabajo duro dará frutos, pero recuerda encontrar tiempo para relajarte. 🏆💆‍♂️",

            "Tauro ♉: " + "Eres paciente, confiable y amas la estabilidad. Prefieres seguir un camino seguro antes de arriesgarte sin pensar.\n" +
                    "Este año, algunos cambios inesperados pueden sacudir tu rutina, pero traerán lecciones valiosas.📚\n" +
                    "❤️ En el amor, podrías fortalecer lazos o conocer a alguien especial.\n" +
                    "Financieramente, es buen momento para invertir con prudencia. 💰",

            "Géminis ♊: " + "Eres curioso, versátil y con una gran facilidad de adaptación. Siempre buscas aprender algo nuevo y tu mente inquieta no deja de explorar.\n" +
                    "Este año será un período de crecimiento y descubrimientos.\n" +
                    "🚀 Tomarás decisiones que influirán en tu futuro, y la comunicación será clave para evitar malentendidos.\n" +
                    "Confía en tu creatividad para salir adelante. 🎭",

            "Cáncer ♋: " + "Eres protector, emocional y tienes un gran sentido de la empatía.\n" +
                    "Siempre buscas el bienestar de los que amas y sigues tu intuición.\n" +
                    "Este año te ayudará a cerrar ciclos del pasado y a fortalecer tus relaciones personales.\n" +
                    "💖 En lo profesional, proyectos creativos podrían traer sorpresas positivas.\n" +
                    "No olvides cuidar tu bienestar emocional. 🧘‍♂️",

            "Leo ♌: " + "Eres carismático, seguro de ti mismo y con un gran espíritu de liderazgo. 🦁\n" +
                    "Te gusta brillar y destacar en todo lo que haces.\n" +
                    "Este año traerá reconocimiento y éxito en diferentes áreas de tu vida. 🏅📈\n" +
                    "Sin embargo, también debes aprender a delegar y no cargar con todo solo.\n" +
                    "El amor y la amistad jugarán un papel importante en tu crecimiento. 💕",

            "Virgo ♍: " + "Eres analítico, detallista y muy trabajador. 🔍\n" +
                    "Siempre buscas la perfección y te esfuerzas por mejorar en todo lo que haces.\n" +
                    "Este año será clave para organizar tu vida y establecer prioridades. 📅\n" +
                    "Podrías asumir nuevas responsabilidades en el ámbito laboral, lo que te traerá crecimiento. 📊\n" +
                    "No olvides cuidar tu salud y evitar el estrés excesivo. 🏋️‍♀️",

            "Libra ♎: " + "Eres sociable, equilibrado y amante de la armonía. ⚖️\n" +
                    "Te gusta rodearte de belleza y evitas los conflictos a toda costa.\n" +
                    "Este año te traerá oportunidades para encontrar el equilibrio en diferentes aspectos de tu vida. 💫\n" +
                    "Tendrás que tomar decisiones importantes en el amor y el trabajo.\n" +
                    "Aprenderás a priorizar lo que realmente te hace feliz. ❤️",

            "Escorpio ♏: " + "Eres intenso, apasionado y con una gran determinación. 🔥\n" +
                    "Nada te detiene cuando te propones algo y no temes enfrentar desafíos.\n" +
                    "Este año será de transformación y crecimiento personal. 💭\n" +
                    "Tendrás que dejar atrás lo que ya no te aporta y enfocarte en tus verdaderos deseos.\n" +
                    "La pasión y la disciplina te llevarán muy lejos. 🚀",

            "Sagitario ♐: " + "Eres aventurero, optimista y siempre buscas nuevos horizontes. 🌍\n" +
                    "Tu espíritu libre te impulsa a explorar sin miedo al cambio.\n" +
                    "Este año estará lleno de oportunidades para aprender y expandir tu mundo. ✈️📖\n" +
                    "Viajes y nuevas experiencias enriquecerán tu vida.\n" +
                    "En el amor, vivirás momentos emocionantes e inesperados. 🎉💕",

            "Capricornio ♑: " + "Eres responsable, disciplinado y con una gran capacidad de trabajo. 🏆\n" +
                    "Siempre buscas construir un futuro sólido y estable.\n" +
                    "Este año será clave para consolidar logros y avanzar en tu carrera. 📈\n" +
                    "Sin embargo, no olvides que la vida también se trata de disfrutar los momentos pequeños. 🌿\n" +
                    "Tómate un descanso cuando lo necesites. 🛀",

            "Acuario ♒: " + "Eres innovador, humanitario y siempre buscas marcar la diferencia. 🚀\n" +
                    "No sigues las reglas convencionales y disfrutas de tu independencia.\n" +
                    "Este año será ideal para emprender nuevos proyectos y conocer personas que compartirán tu visión. 🌎✨\n" +
                    "En el amor, la honestidad será clave para fortalecer vínculos. 💙\n" +
                    "No tengas miedo de mostrarte tal como eres. 👽",

            "Piscis ♓: " + "Eres soñador, empático y con una gran sensibilidad. 💜\n" +
                    "Tu intuición te guía y siempre estás dispuesto a ayudar a los demás.\n" +
                    "Este año te traerá momentos de introspección y crecimiento emocional. 🔮\n" +
                    "Será un buen período para confiar más en ti mismo y tomar decisiones importantes.\n" +
                    "Tu creatividad te abrirá nuevas puertas en lo personal y profesional. 🎭🎶"
    };



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Se enlacan los text y list view del diseño a java
        encabezado = findViewById(R.id.textView);
        listaZodiaco = findViewById(R.id.listWiew);
        info = findViewById(R.id.acercaDe);
        salir = findViewById(R.id.button);
        //Se agrega a ArrayAdapter el arreglo de los signos en la lita de items
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.list_item_signo, signos);

        listaZodiaco.setAdapter(adapter);

        //implementar clase anoninma enviando como param el adaptador, la vista, posicion e ID en un long
        listaZodiaco.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long l) {
                encabezado.setText("Periodo " + periodos[i]);
                info.setText("" + informacion[i]);
            }
        }
        );

        //Boton2 simplemente sale del sistema al darle click
        salir.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        finishAffinity();
                    }
                }
        );

    }



}
