package com.example.sensores;


import android.app.ListActivity;

import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.ArrayAdapter;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends ListActivity {

    private String[] sensores;
    private List <Sensor> listaSensores;   //listas dinámicas
    private List<String> nombreSensores;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //llamo al manager y tomo de ese celular los servicios.
        SensorManager sensorManager =
                (SensorManager) getSystemService( SENSOR_SERVICE );
        listaSensores = sensorManager.getSensorList(Sensor.TYPE_ALL); //traer todos los sensores que tiene el disp.
        nombreSensores = new ArrayList<String>();

        for (Sensor sensor:  listaSensores) {
            nombreSensores.add(sensor.getName()); //recorre la lista de sensores, toma su nombre y lo agrega a la lista String
        }
        //convertir a cadena estática
        sensores = nombreSensores.toArray(
                new String[nombreSensores.size()] );

        //se llaman adaptadores pq son sensobles a la interacción. En this ventana, llama a la lista del padre
        // y muestra los nombres de sensores
        setListAdapter(new ArrayAdapter<String>(
                this, android.R.layout.simple_list_item_1, sensores));

    }
}